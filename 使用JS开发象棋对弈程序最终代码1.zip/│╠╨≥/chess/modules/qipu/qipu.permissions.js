let permissions = [
  {
    key:"administer qipu", 
    title:"Administer qipu"
  },
  {
    key:"access qipu", 
    title:"Access qipu"
  },
  {
    key:"create qipu", 
    title:"Create qipu"
  }, 
  {
    key:"edit qipu", 
    title:"Edit qipu"
  },
  {
    key:"delete qipu", 
    title:"Delete qipu"
  }
];

export default permissions;