let permissions = [
  {
    key:"administer content", 
    title:"Administer content"
  },
  {
    key:"access content", 
    title:"Access content"
  },
  {
    key:"create content", 
    title:"Create content"
  }, 
  {
    key:"edit content", 
    title:"Edit content"
  },
  {
    key:"delete content", 
    title:"Delete content"
  }
];

export default permissions;