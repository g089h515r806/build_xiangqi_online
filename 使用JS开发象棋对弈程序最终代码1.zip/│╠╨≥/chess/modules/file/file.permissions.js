let permissions = [
  {
    key:"administer file", 
    title:"Administer file"
  },
  {
    key:"access file", 
    title:"Access file"
  },
  {
    key:"create file", 
    title:"Create file"
  }, 
  {
    key:"edit file", 
    title:"Edit file"
  },
  {
    key:"delete file", 
    title:"Delete file"
  }
];

export default permissions;