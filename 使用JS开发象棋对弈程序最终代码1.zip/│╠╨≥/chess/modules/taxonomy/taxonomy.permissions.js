let permissions = [
  {
    key:"administer taxonomy", 
    title:"Administer taxonomy"
  },
  {
    key:"access term", 
    title:"Access term"
  },  
  {
    key:"create term", 
    title:"Create term"
  },  
  {
    key:"edit term", 
    title:"Edit term"
  },
  {
    key:"delete term", 
    title:"Delete term"
  }
];

export default permissions;