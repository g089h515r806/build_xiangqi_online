let permissions = [
  {
    key:"access log", 
    title:"Access log"
  }
];

export default permissions;